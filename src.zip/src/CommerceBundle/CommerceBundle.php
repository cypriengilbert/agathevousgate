<?php

namespace CommerceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CommerceBundle extends Bundle
{
}
