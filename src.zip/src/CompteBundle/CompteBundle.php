<?php

namespace CompteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CompteBundle extends Bundle
{
}
