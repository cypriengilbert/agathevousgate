<?php

namespace PaymentBridgeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PaymentBridgeBundle extends Bundle
{
}
