SensioGeneratorBundle
=====================

The `SensioGeneratorBundle` extends the default Symfony2 command line
interface by providing new interactive and intuitive commands for generating
code skeletons like bundles, form classes, or CRUD controllers based on a
Doctrine 2 schema.

More information in the official
[documentation](http://symfony.com/doc/current/bundles/SensioGeneratorBundle/index.html).
