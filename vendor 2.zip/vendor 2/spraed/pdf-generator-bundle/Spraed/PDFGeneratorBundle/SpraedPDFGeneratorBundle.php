<?php

namespace Spraed\PDFGeneratorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SpraedPDFGeneratorBundle extends Bundle
{
}
